"""dl.kamp-ai(T3Q.ai) 학습 모듈 — IWG 프레스가드 라이트 v1.2

플랫폼이 `python3 -m train`으로 실행한다. 핵심 로직은 제출 소스와 동일한 파일을 그대로 쓴다.
  protocol.py            고정 분석 규칙(분할·블록 교차검증·후보 8개·보정·임계값)
  pressguard_pipeline.py 제출 소스의 train.py와 동일(개발 OOF 선정 → 최종 학습 → 시험 1회 평가)
  analysis.py            보정 진단·중요도·FN/FP 조건·점검 우선순위
  pumpguard/             표준 라이브러리 추론 엔진(추론 서비스에서 사용)

플랫폼 연동
- 데이터: T3QAI_TRAIN_DATA_PATH → T3QAI_TEST_DATA_PATH → 알고리즘 폴더 data/ 순서로 원본 CSV 2개를 찾는다.
  (zip만 있으면 풀어서 사용) 원본 SHA-256이 제출 자료와 다르면 학습을 멈춘다.
- 모델: T3QAI_TRAIN_MODEL_PATH/model.json  (추론 서비스가 이 파일을 읽는다)
- 결과: T3QAI_TRAIN_OUTPUT_PATH 에 그림(PNG)·요약(MD/JSON)·시험 예측(CSV) 저장 → 학습상태 탭에 표시
- 지표: 시험 1회 평가 결과를 train_save_result_metrics / train_save_classification_result 로 전달
"""
import hashlib
import json
import logging
import os
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

import t3qai_client as tc
from t3qai_client import T3QAI_TRAIN_OUTPUT_PATH, T3QAI_TRAIN_MODEL_PATH, T3QAI_TRAIN_DATA_PATH, T3QAI_TEST_DATA_PATH, T3QAI_MODULE_PATH

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
REQUIRED = ("press_data_normal.csv", "outlier_data.csv")


def main():
    result, result_msg = None, "success"
    tc.train_start()
    try:
        train()
    except Exception as e:  # 플랫폼에 오류 상태와 메시지를 남긴다
        result, result_msg = e, e
        logging.exception("PressGuard training failed")
    tc.train_finish(result, result_msg)


def _find_data_dir(candidates, workdir):
    """원본 CSV 2개가 모두 있는 폴더를 반환. zip만 있으면 workdir에 풀어서 다시 찾는다."""
    for base in candidates:
        if not base or not Path(base).exists():
            continue
        base = Path(base)
        if all(any(base.rglob(name)) for name in REQUIRED):
            return base
        zips = list(base.rglob("*.zip"))
        if zips:
            target = Path(workdir) / ("unzipped_" + hashlib.md5(str(base).encode()).hexdigest()[:8])
            target.mkdir(parents=True, exist_ok=True)
            for z in zips:
                with zipfile.ZipFile(z) as f:
                    f.extractall(target)
            if all(any(target.rglob(name)) for name in REQUIRED):
                return target
    raise FileNotFoundError("press_data_normal.csv / outlier_data.csv 를 찾지 못했습니다. 데이터셋에 두 CSV(또는 zip)를 올려주세요.")


def _verify_sources(data_dir):
    manifest = json.loads((HERE / "data" / "SOURCE_HASHES.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        found = list(Path(data_dir).rglob(item["name"]))
        if len(found) != 1:
            raise ValueError(f"{item['name']} 가 {len(found)}개 있습니다. 하나만 두세요.")
        digest = hashlib.sha256(found[0].read_bytes()).hexdigest()
        if digest != item["sha256"]:
            raise ValueError(f"{item['name']} SHA-256 불일치: 제출 자료와 다른 데이터입니다.")
    return True


def _run(script, args):
    """제출 소스의 스크립트를 같은 인터프리터에서 그대로 실행한다(argparse 포함)."""
    import runpy
    old = sys.argv
    sys.argv = [script, *args]
    try:
        runpy.run_path(str(HERE / script), run_name="__main__")
    finally:
        sys.argv = old


def _report_to_platform(output_dir):
    metrics = json.loads((output_dir / "metrics.json").read_text(encoding="utf-8"))
    row = metrics["test"]["rows"]["standard"]; alarm = metrics["test"]["persistent"]["standard"]
    total = row["tp"] + row["fp"] + row["fn"] + row["tn"]
    summary = {"accuracy": (row["tp"] + row["tn"]) / total, "precision": row["precision"], "recall": row["recall"],
               "f1": row["f1"], "loss": row.get("brier_judged"), "ap": row.get("ap_judged"), "roc_auc": row.get("roc_auc_judged"),
               "persistent_alarm_f1": alarm["f1"], "anomalous_segments_detected": alarm["anomalous_segments_detected"],
               "selected_model": metrics["selected_model"]}
    logging.info("test summary (standard mode): %s", summary)
    # 플랫폼 차트 규격(t3qai_client 1.1.2): accuracy/loss/step 만 전달. 나머지 지표는 결과 파일·로그로 제공
    if hasattr(tc, "train_save_result_metrics"):
        tc.train_save_result_metrics({"accuracy": float(summary["accuracy"]), "loss": float(summary["loss"] or 0.0), "step": 1})
    if hasattr(tc, "train_save_classification_result"):
        import csv
        with (output_dir / "predictions_test.csv").open(encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
        tc.train_save_classification_result({
            "predict_y": [int(r["decision_standard"]) for r in rows],
            "actual_y": [[int(r["label"])] for r in rows],
            "test_id": list(range(len(rows))),
            "loss": float(row.get("brier_judged") or 0.0)})
    return summary


def _max_numeric_diff(a, b):
    """두 JSON 값의 최대 수치 차이(구조·문자열이 다르면 inf). 플랫폼 하드웨어의 부동소수점 끝자리 차이를 판별."""
    if isinstance(a, dict) and isinstance(b, dict):
        if a.keys() != b.keys():
            return float("inf")
        return max([_max_numeric_diff(a[k], b[k]) for k in a] or [0.0])
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return float("inf")
        return max([_max_numeric_diff(x, y) for x, y in zip(a, b)] or [0.0])
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        return abs(float(a) - float(b))
    return 0.0 if a == b else float("inf")


def _bundle_mode(model_dir, output_dir, reason):
    """재학습 없이 제출 번들 모델과 그 결과를 그대로 배포(학습 패키지가 없는 실행환경용)."""
    logging.warning("bundle mode: %s", reason)
    shutil.copy(HERE / "pumpguard" / "model.json", model_dir / "model.json")
    for f in (HERE / "bundle_results").iterdir():
        shutil.copy(f, output_dir / f.name)
    (output_dir / "platform_check.txt").write_text(
        "train_mode: bundle (submitted model deployed without retraining)\nreason: " + reason + "\n"
        "bundled sha256: " + hashlib.sha256((HERE / "pumpguard" / "model.json").read_bytes()).hexdigest() + "\n"
        "python: " + sys.version.split()[0] + "\n", encoding="utf-8")
    if not (model_dir / "pumpguard_engine").exists():
        shutil.copytree(HERE / "pumpguard", model_dir / "pumpguard_engine")
    return _report_to_platform(output_dir)


def train():
    params = tc.train_load_param() or {}
    logging.info("platform params: %s", params)
    model_dir = Path(T3QAI_TRAIN_MODEL_PATH or os.environ.get("PRESSGUARD_MODEL_DIR", HERE / "_local_model"))
    output_dir = Path(T3QAI_TRAIN_OUTPUT_PATH or (model_dir / "t3qai_output"))
    model_dir.mkdir(parents=True, exist_ok=True); output_dir.mkdir(parents=True, exist_ok=True)
    # 모델 파라미터 train_mode=bundle 이거나 학습 패키지가 없으면 제출 모델을 그대로 배포
    if str(params.get("train_mode", "full")).lower() == "bundle":
        return _bundle_mode(model_dir, output_dir, "model parameter train_mode=bundle")
    try:
        import numpy, pandas, sklearn, matplotlib  # noqa: F401
    except ImportError as e:
        return _bundle_mode(model_dir, output_dir, f"training packages missing ({e})")
    work = Path(tempfile.mkdtemp(prefix="pressguard_"))
    data_dir = _find_data_dir([T3QAI_TRAIN_DATA_PATH, T3QAI_TEST_DATA_PATH, os.environ.get("PRESSGUARD_DATA_DIR"),
                               T3QAI_MODULE_PATH and Path(T3QAI_MODULE_PATH) / "data", HERE / "data"], work)
    _verify_sources(data_dir)
    logging.info("data dir: %s (SHA-256 verified)", data_dir)

    # 1) 제출 소스와 동일한 학습·선정·시험 파이프라인 (결과 폴더는 하위폴더 없이 평평하게)
    _run("pressguard_pipeline.py", ["--data-dir", str(data_dir), "--output-dir", str(output_dir),
                                    "--model-path", str(model_dir / "model.json"),
                                    "--reference-model", str(HERE / "reference" / "model_v1.1_extratrees.json")])
    # 2) 오류·중요도·점검 우선순위 분석(선택: 모델 파라미터 run_analysis=false 로 끌 수 있음)
    if str(params.get("run_analysis", "true")).lower() != "false":
        _run("analysis.py", ["--data-dir", str(data_dir), "--output-dir", str(output_dir)])

    # 큰 중간 CSV는 화면 표시용 결과 폴더 대신 모델 폴더에 보관
    details = model_dir / "details"; details.mkdir(exist_ok=True)
    for name in ("oof_development.csv", "split_manifest.csv", "error_examples.csv"):
        if (output_dir / name).exists():
            shutil.move(str(output_dir / name), str(details / name))
    # 3) 제출본(번들 모델)과 같은 판정을 내는지 확인해 로그로 남긴다
    bundled = json.loads((HERE / "pumpguard" / "model.json").read_text(encoding="utf-8"))
    rebuilt = json.loads((model_dir / "model.json").read_text(encoding="utf-8"))
    same = bundled == rebuilt
    model_diff = _max_numeric_diff(bundled, rebuilt)
    import csv
    with (output_dir / "predictions_test.csv").open(encoding="utf-8-sig") as f:
        new_rows = list(csv.DictReader(f))
    with (HERE / "bundle_results" / "predictions_test.csv").open(encoding="utf-8-sig") as f:
        old_rows = list(csv.DictReader(f))
    keys = ("decision_unmanned", "decision_standard", "decision_screening", "alarm_standard")
    decisions_same = len(new_rows) == len(old_rows) and all(a[k] == b[k] for a, b in zip(new_rows, old_rows) for k in keys)
    score_diff = max(abs(float(a["score"]) - float(b["score"])) for a, b in zip(new_rows, old_rows))
    (output_dir / "platform_check.txt").write_text(
        f"test decisions/alarms identical to submitted results: {decisions_same} (max score diff {score_diff:.3e})\n"
        f"model.json numerically identical to submitted bundle (|diff| <= 1e-9): {model_diff <= 1e-9} (max |diff| {model_diff:.3e}; byte-identical: {same})\n"
        f"bundled sha256: {hashlib.sha256((HERE / 'pumpguard' / 'model.json').read_bytes()).hexdigest()}\n"
        f"rebuilt sha256: {hashlib.sha256((model_dir / 'model.json').read_bytes()).hexdigest()}\n"
        f"python: {sys.version.split()[0]}\n", encoding="utf-8")
    # 추론 서비스가 쓰는 엔진과 원본 해시도 모델 폴더에 함께 둔다
    shutil.copytree(HERE / "pumpguard", model_dir / "pumpguard_engine", dirs_exist_ok=True)
    shutil.copy(model_dir / "model.json", model_dir / "pumpguard_engine" / "model.json")
    summary = _report_to_platform(output_dir)
    logging.info("decisions identical: %s | model.json identical: %s | test F1 %.4f", decisions_same, same, summary["f1"])
    shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    main()
