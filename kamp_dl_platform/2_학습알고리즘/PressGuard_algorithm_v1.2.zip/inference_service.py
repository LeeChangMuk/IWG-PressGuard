"""dl.kamp-ai(T3Q.ai) 추론 모듈 — IWG 프레스가드 라이트 v1.2

추론은 학습 결과 model.json 을 표준 라이브러리 엔진(pumpguard/inference.py)으로 실행한다.
scikit-learn 없이 동작하며, 제출 소스·현장 EXE와 같은 점수·판정·지속성 경보를 낸다.

입력(JSON 추론, inference_dataframe)
  - 시간 순서대로 정렬된 연속 표본 여러 행. 열: TimeStamp, AI0_Vibration, AI1_Vibration, AI2_Current
  - 열 이름이 없으면 위 순서로 해석. 선택 5번째 열/키 'mode' = unmanned | standard | screening
  - 예) [["2022-07-17 10:53:18.444", 0.12, -0.03, 140.2], ["2022-07-17 10:53:18.544", 0.31, 0.05, 131.0], ...]
  - 새 구간의 처음 2표본은 '준비(WARMUP)'로 판정하지 않으므로 4행 이상 보내야 경보가 가능
출력: 행별 이상확률(score)·판정·상태·근거 + 요약(경보 진입 건수 등)

입력(파일 추론, inference_file): 센서 CSV 1개 이상 → 행별 결과 CSV(+요약 JSON) 반환
"""
import csv
import io
import json
import logging
import os
import sys
import tempfile
from pathlib import Path

import t3qai_client as tc
from t3qai_client import T3QAI_INIT_MODEL_PATH, T3QAI_MODULE_PATH, DownloadFile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pumpguard.inference import load_model, StreamAnalyzer, analyze_csv, OPERATING_MODES  # noqa: E402

COLUMNS = ["TimeStamp", "AI0_Vibration", "AI1_Vibration", "AI2_Current"]


def init_model():
    candidates = []
    if T3QAI_INIT_MODEL_PATH:
        candidates += [Path(T3QAI_INIT_MODEL_PATH) / "model.json", Path(T3QAI_INIT_MODEL_PATH) / "pumpguard_engine" / "model.json"]
    candidates.append(HERE / "pumpguard" / "model.json")          # 학습 결과가 없을 때 제출 번들 모델
    path = next(p for p in candidates if p.exists())
    model = load_model(path)
    params = {}
    try:
        params = tc.inference_load_param() or {}
    except Exception:
        pass
    mode = str(params.get("operating_mode", "standard"))
    if mode not in OPERATING_MODES:
        mode = "standard"
    logging.info("PressGuard model loaded: %s (%s), default mode %s", path, model.get("model_id"), mode)
    return {"model": model, "model_path": str(path), "default_mode": mode}


def _rows_from_input(data):
    """DataFrame / list[list] / list[dict] / dict(columns, values) 를 (rows, mode) 로 정규화."""
    mode = None
    try:
        import pandas as pd
        if isinstance(data, pd.DataFrame):
            cols = [str(c) for c in data.columns]
            data = data.values.tolist() if not set(COLUMNS) <= set(cols) else data[COLUMNS + (["mode"] if "mode" in cols else [])].values.tolist()
    except ImportError:
        pass
    if isinstance(data, dict):
        mode = data.get("mode")
        data = data.get("values") or data.get("data") or data.get("rows") or []
    rows = []
    for item in data:
        if isinstance(item, dict):
            mode = item.get("mode", mode)
            rows.append([item[c] for c in COLUMNS])
        else:
            item = list(item)
            if len(item) >= 5 and str(item[4]) in OPERATING_MODES:
                mode = str(item[4])
            rows.append(item[:4])
    if not rows:
        raise ValueError("입력 행이 없습니다. [[TimeStamp, AI0, AI1, AI2], ...] 형식으로 보내주세요.")
    return rows, mode


def inference_dataframe(data, model_info_dict):
    model = model_info_dict["model"]
    rows, mode = _rows_from_input(data)
    mode = mode if mode in OPERATING_MODES else model_info_dict["default_mode"]
    analyzer = StreamAnalyzer(model, mode)
    out, events = [], 0
    for r in rows:
        r = (list(r) + ["", "", "", ""])[:4]
        # Conversion is left to the engine: a missing or non-numeric value becomes an INVALID row
        # (history reset) instead of failing the whole request.
        rec = analyzer.update([r[1], r[2], r[3]], str(r[0]))
        events += int(bool(rec.get("alarm_event")))
        out.append({"TimeStamp": rec.get("timestamp", str(r[0])), "score": None if rec["score"] is None else round(float(rec["score"]), 6),
                    "predicted": bool(rec["predicted"]), "alarm": bool(rec["alarm"]), "status": rec["status"], "reason": rec.get("reason", "")})
    return {"model_id": model.get("model_id"), "mode": mode, "threshold": model["operating_modes"][mode]["threshold"],
            "rows": len(out), "alarm_events": events,
            "note": "데이터셋 기준 보정 이상확률. 실제 고장확률·잔여수명 아님. 처음 2표본(준비)은 판정하지 않음.",
            "results": out}


def inference_file(files, model_info_dict, data=None):
    model = model_info_dict["model"]
    mode = model_info_dict["default_mode"]
    if isinstance(data, dict) and data.get("mode") in OPERATING_MODES:
        mode = data["mode"]
    results = []
    for f in files:
        raw = f.file.read() if hasattr(f, "file") else Path(f).read_bytes()
        name = Path(getattr(f, "filename", "input.csv")).stem
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "input.csv"; src.write_bytes(raw)
            analysis = analyze_csv(src, model, mode=mode)
        buf = io.StringIO()
        recs = analysis["records"]
        keys = ["timestamp", "score", "predicted", "alarm", "status", "reason"]
        w = csv.DictWriter(buf, fieldnames=keys, extrasaction="ignore"); w.writeheader(); w.writerows(recs)
        results.append(DownloadFile(file_name=f"{name}_pressguard_{mode}.csv", file_obj=io.BytesIO(buf.getvalue().encode("utf-8-sig"))))
        results.append(DownloadFile(file_name=f"{name}_summary.json",
                                    file_obj=io.BytesIO(json.dumps(analysis["summary"], ensure_ascii=False, indent=2, default=str).encode("utf-8"))))
    return results
